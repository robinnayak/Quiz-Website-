// src/components/Login.js
import React, { useState } from "react";
import axios from "axios";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import logo from "../image/quiz.png";
import { setAuth } from "../app/features/auth/AuthSlice";
import { BASE_URL } from "../components/services/baseurl";

const Login = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [data, setData] = useState({
    username: "",
    password: "",
  });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (name, value) => {
    setData({ ...data, [name]: value });
  };

  const handleLogin = async () => {
    setLoading(true);
    setError(null); // Clear previous errors

    try {
      const response = await axios.post(
        `${BASE_URL}/login/`,
        {
          username: data.username,
          password: data.password,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      setLoading(false);
      if (response.data && response.data.token && response.data.user) {
        dispatch(
          setAuth({
            userData: response.data.user,
            token: response.data.token.access,
          })
        );
        // alert("Successfully logged in");
        navigate("/", { state: { data: response.data.user } });
      } else {
        throw new Error("Invalid response from server");
      }
    } catch (error) {
      console.error("Login error", error.response?.data || error.message);
      const errorMessage =
        error.response?.data?.detail || "An error occurred during login";
      setError(errorMessage);
      alert(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 min-h-screen flex flex-col justify-center items-center p-5">
      <div className="flex flex-col items-center mb-5 animate-bounceIn">
        <img src={logo} alt="Quiz Logo" className="w-24 h-24" />
        <h2 className="mt-2 text-2xl font-bold text-white">
          Login With Quiz
        </h2>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-lg w-80 animate-slideInUp">
        <div className="mb-4">
          <label
            htmlFor="username"
            className="block font-semibold text-gray-700"
          >
            Username:
          </label>
          <input
            type="text"
            id="username"
            placeholder="Username"
            value={data.username}
            onChange={(e) => handleChange("username", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500 transition"
          />
        </div>

        <div className="mb-4">
          <label
            htmlFor="password"
            className="block font-semibold text-gray-700"
          >
            Password:
          </label>
          <input
            type="password"
            id="password"
            placeholder="Your password"
            value={data.password}
            onChange={(e) => handleChange("password", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500 transition"
          />
        </div>

        <button
          onClick={handleLogin}
          className={`w-full py-2 mt-4 text-white bg-purple-600 font-bold hover:bg-purple-700 transition rounded ${
            loading
              ? "bg-green-400 cursor-not-allowed"
              : "bg-green-500 hover:bg-green-600 transition"
          }`}
          disabled={loading}
        >
          {loading ? "Loading..." : "Login"}
        </button>

        <button
          onClick={() => navigate("/register")}
          className="w-full py-2 mt-4 text-purple-600 font-bold hover:text-purple-700 transition"
        >
          Don't have an account? Register here
        </button>
      </div>

      {error && (
        <div className="mt-5 text-red-500 text-center animate-shake">
          {error}
        </div>
      )}
    </div>
  );
};

export default Login;
