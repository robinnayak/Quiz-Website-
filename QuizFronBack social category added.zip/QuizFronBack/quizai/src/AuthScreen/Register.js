// src/components/Register.js
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import logo from "../image/quiz.png"; // Adjust the path based on your project structure
import { BASE_URL } from "../components/services/baseurl";

const Register = () => {
  const navigate = useNavigate();
  const [data, setData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    isPlayer: false,
  });
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchRegisterData();
  }, []);

  const fetchRegisterData = async () => {
    console.log("fetching data");
    try {
      const response = await axios.get(`${BASE_URL}/register/`);
      console.log("response", response.data);
    } catch (error) {
      console.log("error", error);
    }
  };

  const handleChange = (name, value) => {
    setData({ ...data, [name]: value });
  };

  const handleRegister = async () => {
    if (data.password !== data.confirmPassword) {
      alert("Password and confirm password do not match");
      return;
    }

    console.log("data", data);

    try {
      const response = await axios.post(
        `${BASE_URL}/register/`,
        {
          username: data.username,
          email: data.email,
          password: data.password,
          password2: data.confirmPassword,
          is_player: data.isPlayer,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("response", response.data);
      // alert("You have successfully registered");
      navigate("/login");
    } catch (error) {
      const errorMessage =
        error.response?.data?.errors || "An error occurred. Please try again.";
      setError(errorMessage);
      alert(errorMessage);
      console.error("error", error);
    }
  };

  return (
    <div className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 min-h-screen flex flex-col justify-center items-center p-5">
      <div className="flex flex-col items-center mb-5 animate-bounceIn">
        <img src={logo} alt="Quiz Logo" className="w-24 h-24" />
        <h2 className="mt-2 text-2xl font-bold text-white">
          Register to Quiz App
        </h2>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-lg w-80 animate-slideInUp">
        <div className="mb-4">
          <label htmlFor="username" className="block font-semibold text-gray-700">
            Username:
          </label>
          <input
            type="text"
            id="username"
            placeholder="Username"
            value={data.username}
            onChange={(e) => handleChange("username", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500 transition"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="email" className="block font-semibold text-gray-700">
            Email:
          </label>
          <input
            type="email"
            id="email"
            placeholder="Email"
            value={data.email}
            onChange={(e) => handleChange("email", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500 transition"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="password" className="block font-semibold text-gray-700">
            Password:
          </label>
          <input
            type="password"
            id="password"
            placeholder="Password"
            value={data.password}
            onChange={(e) => handleChange("password", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500 transition"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="confirmPassword" className="block font-semibold text-gray-700">
            Confirm Password:
          </label>
          <input
            type="password"
            id="confirmPassword"
            placeholder="Confirm Password"
            value={data.confirmPassword}
            onChange={(e) => handleChange("confirmPassword", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500 transition"
          />
        </div>

        <div className="flex items-center mb-4">
          <input
            type="checkbox"
            id="isPlayer"
            checked={data.isPlayer}
            onChange={() => setData({ ...data, isPlayer: !data.isPlayer })}
            className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
          />
          <label htmlFor="isPlayer" className="ml-2 text-gray-700">
            Are you a Player?
          </label>
        </div>

        <button
          onClick={handleRegister}
          className="w-full py-2 mt-4 text-white font-bold bg-purple-600 rounded hover:bg-purple-700 transition"
        >
          Register
        </button>

        <button
          onClick={() => navigate("/login")}
          className="w-full py-2 mt-4 text-purple-600 font-bold hover:text-purple-700 transition"
        >
          Already have an account? Login here
        </button>
      </div>

      {error && (
        <div className="mt-5 text-red-500 text-center animate-shake">{error}</div>
      )}
    </div>
  );
};

export default Register;
