import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import logo from "../image/quiz.png"; 
import SvgImage from "./common/SvgImage"; 
import Logout from "../AuthScreen/Logout"; 

const Navbar = () => {
  const auth = useSelector((state) => state.auth); 
  const isAuthenticated = !!auth.token; 
  const [isLoggedIn, setIsLoggedIn] = useState(isAuthenticated);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  useEffect(() => {
    setIsLoggedIn(isAuthenticated);
  }, [isAuthenticated]);

  const handleDropdownToggle = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleClickOutside = (event) => {
    if (!event.target.closest('.dropdown')) {
      setIsDropdownOpen(false);
    }
  };

  useEffect(() => {
    if (isDropdownOpen) {
      document.addEventListener('click', handleClickOutside);
    } else {
      document.removeEventListener('click', handleClickOutside);
    }
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [isDropdownOpen]);

  return (
    <nav className="bg-gradient-to-r from-green-400 via-pink-500 to-purple-500 p-2 flex justify-between items-center shadow-md border-b-2 border-white  text-white font-semibold">
      <div className="flex items-center">
        <Link to="/">
          <img src={logo} alt="Logo" className="h-12 animate-spinSlow" />
        </Link>
      </div>
      <ul className="flex flex-1 justify-center gap-8 text-lg">
        <li>
          <Link
            to="/"
            className="hover:text-gray-300 transition-colors"
          >
            Home
          </Link>
        </li>
        <li>
          <Link
            to="/about"
            className="hover:text-gray-300 transition-colors"
          >
            About
          </Link>
        </li>
        <li>
          <Link
            to="/contact"
            className="hover:text-gray-300 transition-colors"
          >
            Contact
          </Link>
        </li>
        <li>
          <Link
            to="/score"
            className="hover:text-gray-300 transition-colors"
          >
            Check Score
          </Link>
        </li>
      </ul>

      <div className="flex items-center gap-4">
        {!isLoggedIn ? (
          <>
            <Link
              to="/login"
              className="hover:text-gray-300 transition-colors"
            >
              Login
            </Link>
            <Link
              to="/register"
              className="hover:text-gray-300 transition-colors"
            >
              Signup
            </Link>
          </>
        ) : (
          <div className="relative inline-block dropdown">
            <div onClick={handleDropdownToggle} className="cursor-pointer">
              <SvgImage seed={auth.username} className="w-12 h-12" />
            </div>
            {isDropdownOpen && (
              <div className="dropdownContent absolute right-0 mt-2 w-48 bg-white shadow-lg rounded-lg transition-opacity duration-300 z-10">
                <Link
                  to="/settings"
                  className="block px-4 py-2 text-gray-800 hover:bg-gray-100 rounded-t-lg"
                >
                  Settings
                </Link>
                <Link
                  to="/score"
                  className="block px-4 py-2 text-gray-800 hover:bg-gray-100"
                >
                  Check Score
                </Link>
                <Logout /> {/* Use the Logout component here */}
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
