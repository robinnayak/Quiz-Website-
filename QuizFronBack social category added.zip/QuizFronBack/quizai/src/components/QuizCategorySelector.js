// src/components/QuizCategorySelector.js
import React, { useState } from "react";

const QuizCategorySelector = ({
  categories,
  onSelectCategory,
  onSelectNumQuestions,
}) => {
  const [selectedCategory, setSelectedCategory] = useState("");
  const [numQuestions, setNumQuestions] = useState(5);

  const handleCategoryChange = (event) => {
    setSelectedCategory(event.target.value);
    onSelectCategory(event.target.value);
  };

  const handleNumQuestionsChange = (event) => {
    const num = parseInt(event.target.value, 10);
    setNumQuestions(num);
    onSelectNumQuestions(num);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto mt-8">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Select a Category and Number of Questions</h2>
      <div className="mb-4">
        <label htmlFor="category" className="block text-gray-700 font-semibold">Category:</label>
        <select
          id="category"
          value={selectedCategory}
          onChange={handleCategoryChange}
          className="w-full mt-2 p-2 border rounded-md focus:ring focus:border-blue-300"
        >
          <option value="" disabled>
            Select a category
          </option>
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>
      <div className="mb-4">
        <label htmlFor="numQuestions" className="block text-gray-700 font-semibold">Number of Questions:</label>
        <input
          type="number"
          id="numQuestions"
          min="1"
          max="10"
          value={numQuestions}
          onChange={handleNumQuestionsChange}
          className="w-full mt-2 p-2 border rounded-md focus:ring focus:border-blue-300"
        />
      </div>
      <button
        onClick={() => onSelectCategory(selectedCategory)}
        className="w-full mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
      >
        Start Quiz
      </button>
    </div>
  );
};

export default QuizCategorySelector;
