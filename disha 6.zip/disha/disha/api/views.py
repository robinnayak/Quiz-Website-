from django.shortcuts import render
from rest_framework import status
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from authentication.renderers import UserRenderer
from organization.models import Review
from organization.serializers import ReviewSerializer
from django.contrib.contenttypes.models import ContentType
from authentication.models import Passenger,Driver,Organization


# Create your views here.

class ReviewCreateAPIView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [UserRenderer]
    def post(self, request, *args, **kwargs):
        data = request.data
        user = request.user

        # Determine the reviewer type
        if user.is_organization:
            reviewer_instance = Organization.objects.get(user=user)
            reviewer_content_type = ContentType.objects.get_for_model(Organization)
        elif user.is_passenger:
            reviewer_instance = Passenger.objects.get(user=user)
            reviewer_content_type = ContentType.objects.get_for_model(Passenger)
        elif user.is_driver:
            reviewer_instance = Driver.objects.get(user=user)
            reviewer_content_type = ContentType.objects.get_for_model(Driver)
        else:
            raise ValidationError("Reviewer type is not recognized.")

        # Set the reviewer info in the request data
        data['reviewer_content_type'] = reviewer_content_type.id
        data['reviewer_object_id'] = reviewer_instance.id

        # Determine the reviewee type based on input data
        reviewee_id = data.get('reviewee_object_id')
        reviewee_type = data.get('reviewee_content_type')

        if not reviewee_id or not reviewee_type:
            raise ValidationError("Reviewee content type and object ID must be provided.")

        if reviewee_type == "driver":
            reviewee_instance = Driver.objects.get(id=reviewee_id)
            reviewee_content_type = ContentType.objects.get_for_model(Driver)
        elif reviewee_type == "organization":
            reviewee_instance = Organization.objects.get(id=reviewee_id)
            reviewee_content_type = ContentType.objects.get_for_model(Organization)
        elif reviewee_type == "passenger":
            reviewee_instance = Passenger.objects.get(id=reviewee_id)
            reviewee_content_type = ContentType.objects.get_for_model(Passenger)
        else:
            raise ValidationError("Reviewee type is not recognized.")

        # Set the reviewee info in the request data
        data['reviewee_content_type'] = reviewee_content_type.id
        data['reviewee_object_id'] = reviewee_instance.id

        # Validate and create the review
        serializer = ReviewSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_201_CREATED)        
       
class ReviewListAPIView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [UserRenderer]
    def get(self, request, *args, **kwargs):
        user = request.user

        # Filter reviews based on the current user type
        if hasattr(user, 'passenger_profile'):
            reviews = Review.objects.filter(
                reviewer_content_type=ContentType.objects.get_for_model(Passenger),
                reviewer_object_id=user.passenger_profile.id
            ) | Review.objects.filter(
                reviewee_content_type=ContentType.objects.get_for_model(Passenger),
                reviewee_object_id=user.passenger_profile.id
            )
        elif hasattr(user, 'driver_profile'):
            reviews = Review.objects.filter(
                reviewer_content_type=ContentType.objects.get_for_model(Driver),
                reviewer_object_id=user.driver_profile.id
            ) | Review.objects.filter(
                reviewee_content_type=ContentType.objects.get_for_model(Driver),
                reviewee_object_id=user.driver_profile.id
            )
        elif hasattr(user, 'organization_profile'):
            reviews = Review.objects.filter(
                reviewer_content_type=ContentType.objects.get_for_model(Organization),
                reviewer_object_id=user.organization_profile.id
            ) | Review.objects.filter(
                reviewee_content_type=ContentType.objects.get_for_model(Organization),
                reviewee_object_id=user.organization_profile.id
            )
        else:
            reviews = Review.objects.none()

        serializer = ReviewSerializer(reviews, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)