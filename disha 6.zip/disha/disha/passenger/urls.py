
from django.urls import path, include
from . import views
urlpatterns = [ 
    path('payment/',views.PaymentCreateView.as_view(),name='payment'),
    path('user-payment/',views.UserPaymentView.as_view(),name='user-payment')   
]


