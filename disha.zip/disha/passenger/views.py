from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from django.db import transaction
from booking.models import Booking
from .models import Payment
from .serializers import PaymentSerializer
from authentication.renderers import UserRenderer

# Create your views here.

class PaymentCreateView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [UserRenderer]
    
    def post(self,request):
        booking_id = request.data.get('booking_id')
        payment_method = request.data.get('payment_method')
        
        if not booking_id or not payment_method:
            return Response({'message':'Please provide both booking_id and payment_method'},status=status.HTTP_400_BAD_REQUEST)
        
        context = {
            'username' : request.user.username,
            'booking_id' : booking_id
        }
        
        serializer = PaymentSerializer(data=request.data,context=context)
        
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    serializer.save()
                return Response({"message":"Payment successful.","data":serializer.data},status=status.HTTP_201_CREATED)
            
            except Exception as e:
                return Response({'error':str(e)},status=status.HTTP_400_BAD_REQUEST)
            
        else:
            return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
        
class UserPaymentView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        payments = Payment.objects.none()

        if user.is_organization:
            payments = Payment.objects.filter(booking__trip__organization=user.organization)
        elif user.is_driver:
            payments = Payment.objects.filter(booking__trip__vehicle__driver=user.driver)
        elif user.is_passenger:
            payments = Payment.objects.filter(passenger__user=user)
        else:
            return Response({"detail": "Invalid user role."}, status=status.HTTP_400_BAD_REQUEST)

        serializer = PaymentSerializer(payments, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)