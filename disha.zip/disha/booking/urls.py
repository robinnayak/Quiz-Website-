from django.urls import path, include
from . import views

urlpatterns = [
    path('create/',views.BookingCreateView.as_view(),name='booking-create'),
    path('filter/',views.BookingFilterView.as_view(),name='booking-filter'),
    path('detail/<str:booking_id>/',views.BookingDetailView.as_view(),name='booking-detail'),     
]

