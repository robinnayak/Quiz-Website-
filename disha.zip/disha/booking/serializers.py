from rest_framework import serializers
from django.contrib.auth.hashers import check_password
from authentication.models import CustomUser,Passenger,Driver
from authentication.serializers import CustomUserSerializer,PassengerSerializer,DriverSerializer
from organization.models import Organization,Trip,TripPrice,Seat
from organization.serializers import OrganizationSerializer,TripSerializer,TripPriceSerializer
from organization.serializers import SeatSerializer
from django.utils import timezone
import random
import string
from .models import Booking,Ticket

from rest_framework import serializers
from .models import Booking, Passenger, Trip, Seat

class BookingSerializer(serializers.ModelSerializer):
    passenger = PassengerSerializer(read_only=True)
    trip = TripSerializer(read_only=True)
    seats = SeatSerializer(many=True)

    class Meta:
        model = Booking
        fields = '__all__'
        extra_kwargs = {
            'num_passengers': {'required': False},
        }

    def validate(self, data):
        seats_data = data.get('seats', [])

        # Check if booking can be updated
        if self.instance:
            if self.instance.is_confirmed:
                raise serializers.ValidationError({"message": "Booking is already confirmed and cannot be updated."})
            if self.instance.is_paid:
                raise serializers.ValidationError({"message": "Booking is already paid and cannot be updated."})

        # Ensure at least one seat is selected
        if not seats_data:
            raise serializers.ValidationError({"seats": "At least one seat must be selected."})

        # Check if any of the selected seats are occupied
        seat_numbers = [seat['seat_number'] for seat in seats_data]
        if Seat.objects.filter(seat_number__in=seat_numbers, is_occupied=True).exists():
            raise serializers.ValidationError({"seats": "One or more seats are already occupied."})

        # Set the number of passengers based on the number of selected seats
        data['num_passengers'] = len(seats_data)

        return data

    def create(self, validated_data):
        user = self.context.get('user')
        trip_id = self.context.get('trip_id')
        seats_data = validated_data.pop('seats', [])

        # Assign passenger to the booking
        try:
            passenger = Passenger.objects.get(user=user)
            validated_data['passenger'] = passenger
        except Passenger.DoesNotExist:
            raise serializers.ValidationError({"message": "Passenger not found"})

        # Assign trip to the booking
        try:
            trip = Trip.objects.get(trip_id=trip_id)
            validated_data['trip'] = trip
        except Trip.DoesNotExist:
            raise serializers.ValidationError({"message": "Trip not found"})

        # Get the Seat objects from the seat numbers
        seat_numbers = [seat['seat_number'] for seat in seats_data]
        seats = Seat.objects.filter(seat_number__in=seat_numbers)

        # Check if all seats are valid
        if seats.count() != len(seat_numbers):
            raise serializers.ValidationError({"seats": "One or more seats are invalid."})

        # Check if any selected seats are occupied
        if seats.filter(is_occupied=True).exists():
            raise serializers.ValidationError({"seats": "One or more seats are already occupied."})

        # Create the booking and assign the seats
        booking = Booking.objects.create(**validated_data)
        booking.seats.set(seats)
        booking.save()
        self.update_seat_occupation_and_vehicle_availability(booking)
        return booking

    def update_seat_occupation_and_vehicle_availability(self,booking):
        print("Running update_seat_occupation_and_vehicle_availability method...")
        
        # Check if the instance is being created (id is None)
        if booking.seats.exists():
            print(f"Updating {booking.seats.count()} seat(s) to occupied status.")
            booking.num_passengers = booking.seats.count()
            booking.seats.update(is_occupied=True)
            booking.trip.vehicle.available_seat -= booking.num_passengers
            booking.trip.vehicle.save()
            print(f"Updated vehicle available seats: {booking.trip.vehicle.available_seat}")
        else:
            print("No seats selected for booking.")
        
    def update(self, instance, validated_data):
        validated_data.pop('seats', None)  # Seats cannot be updated

        # Update only the fields allowed
        instance.is_confirmed = validated_data.get('is_confirmed', instance.is_confirmed)
        instance.is_paid = validated_data.get('is_paid', instance.is_paid)
        instance.save()

        return instance


class TicketSerializer(serializers.ModelSerializer):
    # booking = BookingSerializer(read_only=True)

    class Meta:
        model = Ticket
        fields = '__all__'

    def create(self, validated_data):
        booking_id = self.context.get('booking_id')
        try:
            booking = Booking.objects.get(id=booking_id)
            validated_data['booking'] = booking
        except Booking.DoesNotExist:
            raise serializers.ValidationError({"message": "Booking not found"})

        ticket = Ticket.objects.create(**validated_data)
        return ticket

