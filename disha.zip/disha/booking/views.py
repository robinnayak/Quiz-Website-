from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db import transaction
from .serializers import BookingSerializer, TicketSerializer
from .models import Booking, Ticket
from organization.models import TripPrice, Trip
from authentication.models import Passenger
from rest_framework.permissions import IsAuthenticated
from authentication.renderers import UserRenderer
from django.db import transaction
from django.shortcuts import get_object_or_404

class BookingCreateView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [UserRenderer]

    def post(self, request):
        user = request.user
        trip_id = request.data.get('trip_id', '')
        seats = request.data.get('seats', [])

        if not isinstance(seats, list):
            return Response({"error": "Seats must be provided as a list."}, status=status.HTTP_400_BAD_REQUEST)

        if not Trip.objects.filter(trip_id=trip_id).exists():
            return Response({"error": "Trip not found."}, status=status.HTTP_400_BAD_REQUEST)

        context = {
            'user': user,
            'trip_id': trip_id,
            'seats': seats
        }
        serializer = BookingSerializer(data=request.data, context=context)
        try:
            if serializer.is_valid():
                with transaction.atomic():
                    booking = serializer.save()
                message = {
                    "message": "Booking created successfully",
                    "data": serializer.data
                }
                return Response(message, status=status.HTTP_201_CREATED)
            else:
                return Response({"status": "error", "errors": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"status": "error", "error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
class BookingFilterView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [UserRenderer]
    def get(self, request):
        try:
            queryset = Booking.objects.select_related('trip', 'trip__vehicle').prefetch_related('seats')

            if request.user.is_organization:
                queryset = queryset.filter(trip__organization__user__username=request.user.username)
            elif request.user.is_driver:
                queryset = queryset.filter(trip__vehicle__driver__user__username=request.user.username)
            elif request.user.is_passenger:
                queryset = queryset.filter(passenger__user__username=request.user.username)
            else:
                return Response({"error": "User is not a driver, organization or passenger"}, status=status.HTTP_400_BAD_REQUEST)
            
            serializer = BookingSerializer(queryset, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class BookingDetailView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [UserRenderer]
    def get(self, request, booking_id):
        try:
            booking = get_object_or_404(
                Booking.objects.select_related('trip', 'trip__vehicle').prefetch_related('seats'),
                booking_id=booking_id
            )

            if request.user.is_driver and booking.trip.vehicle.driver.user != request.user:
                return Response({"message": "Not authorized to view this booking."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_organization and booking.trip.organization.user != request.user:
                return Response({"message": "Not authorized to view this booking."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_passenger and booking.passenger.user != request.user:
                return Response({"message": "Not authorized to view this booking."}, status=status.HTTP_403_FORBIDDEN)

            serializer = BookingSerializer(booking)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, booking_id):
        try:
            booking = get_object_or_404(Booking, booking_id=booking_id)

            if request.user.is_driver and booking.trip.vehicle.driver.user != request.user:
                return Response({"message": "Not authorized to update this booking."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_organization and booking.trip.organization.user != request.user:
                return Response({"message": "Not authorized to update this booking."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_passenger and booking.passenger.user != request.user:
                return Response({"message": "Not authorized to update this booking."}, status=status.HTTP_403_FORBIDDEN)

            serializer = BookingSerializer(booking, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response({"message": "Booking updated successfully", "data": serializer.data}, status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, booking_id):
        try:
            booking = get_object_or_404(Booking, booking_id=booking_id)

            if request.user.is_driver and booking.trip.vehicle.driver.user != request.user:
                return Response({"message": "Not authorized to delete this booking."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_organization and booking.trip.organization.user != request.user:
                return Response({"message": "Not authorized to delete this booking."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_passenger and booking.passenger.user != request.user:
                return Response({"message": "Not authorized to delete this booking."}, status=status.HTTP_403_FORBIDDEN)

            booking.delete()
            return Response({"message": "Booking deleted successfully"}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class TicketCreateView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = TicketSerializer(data=request.data)
        try:
            if serializer.is_valid():
                with transaction.atomic():
                    serializer.save()
                message = {
                    "message": "Ticket data retrieved successfully",
                    "data": serializer.data
                }
                return Response(message, status=status.HTTP_201_CREATED)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


# Updated TicketFilterView remains the same
class TicketFilterView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [UserRenderer]
    def get(self, request):
        try:
            queryset = Ticket.objects.select_related('booking__trip', 'booking__trip__vehicle').prefetch_related('booking__seats')

            if request.user.is_driver:
                queryset = queryset.filter(booking__trip__vehicle__driver__user__username=request.user.username)
            elif request.user.is_organization:
                queryset = queryset.filter(booking__trip__organization__user__username=request.user.username)
            else:
                queryset = queryset.filter(booking__passenger__user__username=request.user.username)

            serializer = TicketSerializer(queryset, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


# Updated TicketDetailView
class TicketDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, ticket_id):
        try:
            ticket = get_object_or_404(
                Ticket.objects.select_related('booking__trip', 'booking__trip__vehicle').prefetch_related('booking__seats'),
                ticket_id=ticket_id
            )

            if request.user.is_driver and ticket.booking.trip.vehicle.driver.user != request.user:
                return Response({"message": "Not authorized to view this ticket."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_organization and ticket.booking.trip.organization.user != request.user:
                return Response({"message": "Not authorized to view this ticket."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_passenger and ticket.booking.passenger.user != request.user:
                return Response({"message": "Not authorized to view this ticket."}, status=status.HTTP_403_FORBIDDEN)

            serializer = TicketSerializer(ticket)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, ticket_id):
        try:
            ticket = get_object_or_404(
                Ticket.objects.select_related('booking__trip', 'booking__trip__vehicle').prefetch_related('booking__seats'),
                ticket_id=ticket_id
            )

            if request.user.is_driver and ticket.booking.trip.vehicle.driver.user != request.user:
                return Response({"message": "Not authorized to update this ticket."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_organization and ticket.booking.trip.organization.user != request.user:
                return Response({"message": "Not authorized to update this ticket."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_passenger and ticket.booking.passenger.user != request.user:
                return Response({"message": "Not authorized to update this ticket."}, status=status.HTTP_403_FORBIDDEN)

            serializer = TicketSerializer(ticket, data=request.data, partial=True)
            if serializer.is_valid():
                with transaction.atomic():
                    serializer.save()
                return Response({"message": "Ticket data updated successfully", "data": serializer.data}, status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, ticket_id):
        try:
            ticket = get_object_or_404(
                Ticket.objects.select_related('booking__trip', 'booking__trip__vehicle').prefetch_related('booking__seats'),
                ticket_id=ticket_id
            )

            if request.user.is_driver and ticket.booking.trip.vehicle.driver.user != request.user:
                return Response({"message": "Not authorized to delete this ticket."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_organization and ticket.booking.trip.organization.user != request.user:
                return Response({"message": "Not authorized to delete this ticket."}, status=status.HTTP_403_FORBIDDEN)
            elif request.user.is_passenger and ticket.booking.passenger.user != request.user:
                return Response({"message": "Not authorized to delete this ticket."}, status=status.HTTP_403_FORBIDDEN)

            with transaction.atomic():
                ticket.delete()
            return Response({"message": "Ticket deleted successfully"}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)