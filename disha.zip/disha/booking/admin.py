from django.contrib import admin
from .models import Booking,Ticket

# Register your models here.

admin.site.register(Booking)
admin.site.register(Ticket)