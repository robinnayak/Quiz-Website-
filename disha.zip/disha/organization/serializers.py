from rest_framework import serializers
from authentication.models import CustomUser,Driver,Organization,Passenger
from authentication.serializers import CustomUserSerializer,OrganizationSerializer,DriverSerializer,PassengerSerializer
from .models import Vehicle,Review,Seat,Trip,TripPrice
import random
import string
from django.utils import timezone

class VehicleSerializer(serializers.ModelSerializer):
    organization = OrganizationSerializer(read_only=True)
    driver = DriverSerializer(read_only=True)

    class Meta:
        model = Vehicle
        fields = '__all__'

    def create(self, validated_data):
        user = self.context.get('user')
        dri_license = self.context.get('dri_license')
        check_driver = self.context.get('check_driver')

        validated_data = self._assign_organization_and_driver(validated_data, user, dri_license, check_driver)
        veh_id = self._generate_random_string()
        reg_id = self._generate_registration_number(veh_id, validated_data['organization'].user.username)
        validated_data['registration_number'] = reg_id

        vehicle = Vehicle.objects.create(**validated_data)
        return vehicle

    def update(self, instance, validated_data):
        # Ensure these fields are not updated
        validated_data.pop('registration_number', None)
        validated_data.pop('license_plate_number', None)
        validated_data.pop('organization', None)
        validated_data.pop('driver', None)
        
        #here also available seat shouldn't be changed or updated

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance

    def _assign_organization_and_driver(self, validated_data, user, dri_license, check_driver):
        if check_driver and dri_license:
            try:
                driver = Driver.objects.get(license_number=dri_license)
                validated_data['driver'] = driver
            except Driver.DoesNotExist:
                raise serializers.ValidationError("Driver with the provided license number does not exist.")
        else:
            validated_data['driver'] = None

        validated_data.pop('organization', None)
        try:
            org_mail = Organization.objects.get(user=user)
            validated_data['organization'] = org_mail
        except Organization.DoesNotExist:
            raise serializers.ValidationError("Organization for the provided user does not exist.")

        return validated_data

    @staticmethod
    def _generate_random_string(length=4):
        return ''.join(random.choices(string.digits, k=length))

    @staticmethod
    def _generate_registration_number(id, username):
        org_initials = username[:2].upper()
        return f"VEH-{org_initials}-{id}"

# Review Serializer
class ReviewSerializer(serializers.ModelSerializer):
    reviewer = serializers.SerializerMethodField(read_only=True)
    reviewee = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Review
        fields = '__all__'

    def get_reviewer(self, obj):
        """Return the serialized reviewer object based on its type."""
        reviewer = obj.reviewer
        if isinstance(reviewer, Passenger):
            return PassengerSerializer(reviewer).data
        elif isinstance(reviewer, Driver):
            return DriverSerializer(reviewer).data
        elif isinstance(reviewer, Organization):
            return OrganizationSerializer(reviewer).data
        return None

    def get_reviewee(self, obj):
        """Return the serialized reviewee object based on its type."""
        reviewee = obj.reviewee
        if isinstance(reviewee, Passenger):
            return PassengerSerializer(reviewee).data
        elif isinstance(reviewee, Driver):
            return DriverSerializer(reviewee).data
        elif isinstance(reviewee, Organization):
            return OrganizationSerializer(reviewee).data
        return None

    def validate(self, data):
        reviewer_content_type = data.get('reviewer_content_type')
        reviewer_object_id = data.get('reviewer_object_id')
        reviewee_content_type = data.get('reviewee_content_type')
        reviewee_object_id = data.get('reviewee_object_id')

        if reviewer_content_type == reviewee_content_type and reviewer_object_id == reviewee_object_id:
            raise serializers.ValidationError("Reviewer and reviewee cannot be the same.")
        
        return data

    def create(self, validated_data):
        return super().create(validated_data)

    def update(self, instance, validated_data):
        return super().update(instance, validated_data)
# Seat Serializer
class SeatSerializer(serializers.ModelSerializer):
    vehicle = VehicleSerializer(read_only=True)

    class Meta:
        model = Seat
        fields = '__all__'

    def update(self, instance, validated_data):
        seat_number = validated_data.get('seat_number', instance.seat_number)
        is_occupied = validated_data.get('is_occupied', instance.is_occupied)

        if seat_number != instance.seat_number:
            instance.seat_number = seat_number
        
        if is_occupied != instance.is_occupied:
            instance.is_occupied = is_occupied

        instance.save()

        vehicle = instance.vehicle
        if vehicle:
                if is_occupied:
                    vehicle.seating_capacity -= 1
                else:
                    vehicle.seating_capacity += 1
                vehicle.save()

        return instance
    
    def reset_all_seats(self):
        """
        Resets all seats to unoccupied status at the end of the day.
        """
        today = timezone.now().date()
        vehicles = Vehicle.objects.all()  # You may filter vehicles based on specific criteria if needed

        for vehicle in vehicles:
            # Get all seats for the vehicle
            seats = vehicle.seats.all()

            # Reset each seat to not occupied
            for seat in seats:
                seat.is_occupied = False
                seat.save()

            # Update vehicle available seats count
            vehicle.available_seat = vehicle.seating_capacity
            vehicle.save()

# Trip Serializer

class TripSerializer(serializers.ModelSerializer):
    organization = OrganizationSerializer(read_only=True)
    vehicle = VehicleSerializer(read_only=True)
    class Meta:
        model = Trip
        fields = '__all__'

    def create(self, validated_data):
        
        validated_data.pop('registration_number', None)
        validated_data.pop('price',None)
        org_email = self.context.get('org_email')
        vehicle_registration = self.context.get('registration_number')
        if vehicle_registration:
            try:
                vehicle = Vehicle.objects.get(registration_number=vehicle_registration)
                validated_data['vehicle'] = vehicle
            except Vehicle.DoesNotExist:
                raise serializers.ValidationError("Vehicle with the provided registration number does not exist.")
        else:
            raise serializers.ValidationError("Vehicle registration number is required to create a trip.")

        if org_email:
            try:
                org_mail = Organization.objects.get(user__email=org_email)
                validated_data['organization'] = org_mail
            except Organization.DoesNotExist:
                raise serializers.ValidationError("Organization with the provided email does not exist.")
        else:
            raise serializers.ValidationError("Organization email is required to create a trip.")

        
        trip = Trip.objects.create(**validated_data)
        return trip
    def update(self, instance, validated_data):
        # Ensure these fields are not updated
        validated_data.pop('organization', None)
        validated_data.pop('trip_id', None)
        validated_data.pop('vehicle', None)
        validated_data.pop('from_location', None)
        validated_data.pop('to_location', None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance
        


# class TripSerializer(serializers.ModelSerializer):
#     organization = OrganizationSerializer(read_only=True)

#     class Meta:
#         model = Trip
#         fields = '__all__'
#         read_only_fields = ['trip_id', 'organization']

#     def create(self, validated_data):
#         print("Entered create method...")
#         org_email = self.context.get('org_email')
#         vehicle_registration = self.context.get('registration_number')
#         print("=========Inside serializer===============")
#         print("Org email:", org_email)
#         print("Vehicle registration:", vehicle_registration)
#         print("=========Inside serializer===============")

#         # Handle organization assignment
#         if org_email:
#             print("Inside org_email check:", org_email)
#             try:
#                 org_mail = Organization.objects.get(user__email=org_email)
#                 validated_data['organization'] = org_mail
#             except Organization.DoesNotExist:
#                 raise serializers.ValidationError("Organization with the provided email does not exist.")
#         else:
#             raise serializers.ValidationError("Organization email is required to create a trip.")

#         # Handle vehicle assignment
#         if vehicle_registration:
#             print("Inside vehicle registration check:", vehicle_registration)
#             try:
#                 vehicle = Vehicle.objects.get(registration_number=vehicle_registration)
#                 validated_data['vehicle'] = vehicle
#             except Vehicle.DoesNotExist:
#                 raise serializers.ValidationError("Vehicle with the provided registration number does not exist.")
#         else:
#             raise serializers.ValidationError("Vehicle registration number is required to create a trip.")

#         # Create the trip
#         trip = Trip.objects.create(**validated_data)
#         return trip















# TripPrice Serializer
class TripPriceSerializer(serializers.ModelSerializer):
    trip = TripSerializer(read_only=True)
    vehicle = VehicleSerializer(read_only=True)

    class Meta:
        model = TripPrice
        fields = '__all__'

    def create(self, validated_data):
        validated_data.pop('', None)
        trip_id = self.context.get('trip_id')
        vehicle_registration_number = self.context.get('vehicle_registration_number')
        org_email = self.context.get('org_email')

        try:
            trip = Trip.objects.get(id=trip_id, organization__user__email=org_email)
        except Trip.DoesNotExist:
            raise serializers.ValidationError("Trip with the provided ID and organization email does not exist.")

        try:
            vehicle = Vehicle.objects.get(registration_number=vehicle_registration_number)
        except Vehicle.DoesNotExist:
            raise serializers.ValidationError("Vehicle with the provided registration number does not exist.")

        validated_data['trip'] = trip
        validated_data['vehicle'] = vehicle

        trip_price = TripPrice.objects.create(**validated_data)
        return trip_price