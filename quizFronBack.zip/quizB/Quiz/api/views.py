import logging
from django.shortcuts import render,HttpResponse
from django.contrib.auth import authenticate,login,logout
from .models import CustomUser,Question,QuestionSet,Score
from rest_framework.views import APIView   
from .serializers import CustomUserSerializer,CustomUserLoginSerializer, QuestionSerializer, UserWithQuestionCountSerializer, QuestionSetSerializer,ScoreSerializer
from django.contrib.auth.models import Group 
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated   
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken  
from .renderers import UserRenderer 
from rest_framework.exceptions import NotFound
import os
import google.auth
from google.oauth2 import service_account
from googleapiclient.discovery import build
import re
import google.generativeai as genai 

# Create your views here.
def get_tokens_for_user(user):
    refersh = RefreshToken.for_user(user)
    return{
        'refresh':str(refersh),
        'access':str(refersh.access_token)
    }
    
class HomeView(APIView):
    def get(self, request):
        return Response("hello world", status=status.HTTP_200_OK)  
    
    
class RegistrationView(APIView):
    renderer_classes = [UserRenderer]
    
    def get(self, request):
        try:
            users = CustomUser.objects.all()
            serializer = CustomUserSerializer(users, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        data = request.data
        serializer = CustomUserSerializer(data=data)
        
        if serializer.is_valid():
            try:
                user = serializer.save()
                if user.is_player: 
                    self._assign_group(user, 'player')
                    token = self._generate_token_for_user(user) 
                
                else:
                    self._assign_group(user, 'owner')
                    token = self._generate_token_for_user(user)
                
                message = {
                    'message': 'User created successfully',
                    'user': serializer.data,
                    'token': token
                }
                return Response(message, status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response(str(e), status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def _assign_group(self, user, group_name):
        """Assign a user to a specific group."""
        group = Group.objects.get(name=group_name)
        user.groups.add(group)
        
    def _generate_token_for_user(self, user):
        """Generate JWT token for a user."""
        return get_tokens_for_user(user)   


class RegisterDetailView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [IsAuthenticated]
    def get(self, request):
        try:
            user = request.user
            if user is None:
                return Response({'detail': 'Not authenticated'}, status=status.HTTP_401_UNAUTHORIZED)
            
            serializer = CustomUserSerializer(user)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        try:
            user = request.user
            if user is None:
                return Response({'detail': 'Not authenticated'}, status=status.HTTP_401_UNAUTHORIZED)
            
            serializer = CustomUserSerializer(user, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_200_OK)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):
        try:
            user = request.user
            if user is None:
                return Response({'detail': 'Not authenticated'}, status=status.HTTP_401_UNAUTHORIZED)
            
            user.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST)

    
class LoginView(APIView):
    def get(self,request):
        return Response({"message": "This is a GET Login request"}, status=status.HTTP_200_OK)    
    
    def post(self, request):
        try:
            serializer = CustomUserLoginSerializer(data=request.data)
            if serializer.is_valid():
                username = serializer.validated_data['username']
                password = serializer.validated_data['password']
                user = authenticate(username=username, password=password)
                user = CustomUser.objects.get(username=username)
                if user:
                    login(request, user)
                    token = get_tokens_for_user(user)   
                    
                    message = {
                        'message': 'User logged in successfully',
                        'user': CustomUserSerializer(user).data,
                        'token': token
                    }
                    return Response(message, status=status.HTTP_200_OK)
           
            else:
                if 'non_field_errors' in serializer.errors:
                    return Response(serializer.errors['non_field_errors'], status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST) 
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        
class LogoutView(APIView):
    def get(self,request):
        try:
            user = logout(request)
            print("user",user)  
            message = {
                'message': 'User logged out successfully',
                'user':user    

            }
            return Response(message, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST)
        

class GenerateQuestionsView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        category = request.data.get('category', 'General Knowledge')
        num_questions = request.data.get('num_questions', 10)

        user = request.user
        # Pass the category to the method
        question_set_name = self._get_next_question_set_name(user, category)

        # Create a QuestionSet instance
        question_set = QuestionSet.objects.create(user=user, name=question_set_name)
        print("question set", question_set.id)

        prompt = (
            f"Generate a list of {num_questions} quiz questions for the category \"{category}\" "
            "with four multiple-choice answers each. Format the output as "
            "'**Question X:** [question text] Options: [A. Option 1, B. Option 2, C. Option 3, D. Option 4]' "
            "'**Correct Answer:** Option X'"
        )

        # Call the Google Gemini AI service to generate the questions
        try:
            generated_questions = self._generate_questions(prompt)
            print("Generated Questions:", generated_questions)
        except Exception as e:
            question_set.delete()
            return Response({"error": str(e)}, status=500)

        if not generated_questions:
            question_set.delete()
            return Response({"error": "No questions generated by Gemini AI."}, status=500)

        # Validate and save generated questions
        for question_data in generated_questions:
            serializer = QuestionSerializer(
                data=question_data, 
                context={'request': request, 'question_set': question_set}
            )
            if serializer.is_valid():
                serializer.save()
            else:
                question_set.delete()
                return Response(serializer.errors, status=400)

        question_set_serializer = QuestionSetSerializer(question_set)
        return Response(question_set_serializer.data, status=201)

    def _generate_questions(self, prompt):
        # Ensure the API key is set up
        GOOGLE_API_KEY = "AIzaSyBO1epKeznsNoiVi_F1yO08Ohu1aHRx9Lw"
        if GOOGLE_API_KEY is None:
            raise ValueError('API key is not set. Please set the API key before continuing.')

        # Configure the Gemini AI client
        genai.configure(api_key=GOOGLE_API_KEY)

        model = genai.GenerativeModel('gemini-1.5-flash')

        # Generate content using the Gemini AI model
        response = model.generate_content(prompt)
        print("Gemini AI Response:", response.text)
        
        # Check if the response has any text
        raw_text = response.text
        if not raw_text:
            raise ValueError("No text generated by Gemini AI.")

        # Parse the generated questions from the text
        print("Raw Text:", raw_text)
        return self._parse_questions(raw_text)

    def _parse_questions(self, raw_text):
        # Split the raw text by double newlines to separate each question block
        question_blocks = raw_text.split("\n\n")
        questions = []

        for block in question_blocks:
            if block.strip():
                # Extract the question
                question_match = re.search(r'\*\*Question [0-9]+:\*\*\s*(.+)', block)
                options_match = re.search(r'Options:\s*(.+)', block)
                answer_match = re.search(r'\*\*Correct Answer:\*\*\s*(.+)', block)

                if question_match and options_match and answer_match:
                    question = question_match.group(1).strip()
                    options_text = options_match.group(1).strip()
                    answer_text = answer_match.group(1).strip()

                    # Extract options
                    options = [opt.strip() for opt in options_text.split(',')]
                    correct_option_letter = answer_text[0]  # e.g., "A" from "A. Option 1"
                    correct_option = None

                    # Match correct answer with the corresponding option
                    for i, opt in enumerate(options):
                        if opt.startswith(correct_option_letter):
                            correct_option = i + 1
                            break

                    if len(options) == 4 and correct_option:
                        questions.append({
                            "text": question,
                            "option1": options[0][3:].strip(),  # Remove "A. " from the start
                            "option2": options[1][3:].strip(),
                            "option3": options[2][3:].strip(),
                            "option4": options[3][3:].strip(),
                            "correct_option": correct_option,
                            "question_set": None  # Initially set to None
                        })

        return questions

    def _get_next_question_set_name(self, user, category):
        # Fetch the last created QuestionSet for the user with the same category
        last_question_set = QuestionSet.objects.filter(user=user, name__startswith=category).order_by('-created_at').first()

        if last_question_set:
            # Extract the part number from the last question set name
            last_part_num = int(last_question_set.name.split('part ')[-1])
            return f'{category} - part {last_part_num + 1}'

        # If no previous question sets with the same category, start with part 1
        return f'{category} - part 1'
  
        
        
        
        
        
        
        
        
        
        

# class GenerateQuestionsView(APIView):
#     permission_classes = [IsAuthenticated]

#     def post(self, request, *args, **kwargs):
#         category = request.data.get('category', 'General Knowledge')
#         num_questions = request.data.get('num_questions', 10)

#         user = request.user
#         question_set_name = self._get_next_question_set_name(user)

#         # Create a QuestionSet instance
#         question_set = QuestionSet.objects.create(user=user, name=question_set_name)
#         print("question set", question_set.id)

#         prompt = (
#             f"Generate a list of {num_questions} quiz questions for the category \"{category}\" "
#             "with four multiple-choice answers each. Format the output as "
#             "'**Question X:** [question text] Options: [A. Option 1, B. Option 2, C. Option 3, D. Option 4]' "
#             "'**Correct Answer:** Option X'"
#         )

#         # Call the Google Gemini AI service to generate the questions
#         try:
#             generated_questions = self._generate_questions(prompt)
#             print("Generated Questions:", generated_questions)
#         except Exception as e:
#             question_set.delete()
#             return Response({"error": str(e)}, status=500)

#         if not generated_questions:
#             question_set.delete()
#             return Response({"error": "No questions generated by Gemini AI."}, status=500)

#         # Validate and save generated questions
#         for question_data in generated_questions:
#             serializer = QuestionSerializer(
#                 data=question_data, 
#                 context={'request': request, 'question_set': question_set}
#             )
#             if serializer.is_valid():
#                 serializer.save()
#             else:
#                 question_set.delete()
#                 return Response(serializer.errors, status=400)

#         question_set_serializer = QuestionSetSerializer(question_set)
#         return Response(question_set_serializer.data, status=201)

#     def _generate_questions(self, prompt):
#         # Ensure the API key is set up
#         GOOGLE_API_KEY = "AIzaSyBO1epKeznsNoiVi_F1yO08Ohu1aHRx9Lw"
#         if GOOGLE_API_KEY is None:
#             raise ValueError('API key is not set. Please set the API key before continuing.')

#         # Configure the Gemini AI client
#         genai.configure(api_key=GOOGLE_API_KEY)

#         model = genai.GenerativeModel('gemini-1.5-flash')

#         # Generate content using the Gemini AI model
#         response = model.generate_content(prompt)
#         print("Gemini AI Response:", response.text)
        
#         # Check if the response has any text
#         raw_text = response.text
#         if not raw_text:
#             raise ValueError("No text generated by Gemini AI.")

#         # Parse the generated questions from the text
#         print("Raw Text:", raw_text)
#         return self._parse_questions(raw_text)

#     def _parse_questions(self, raw_text):
#         # Split the raw text by double newlines to separate each question block
#         question_blocks = raw_text.split("\n\n")
#         questions = []

#         for block in question_blocks:
#             if block.strip():
#                 # Extract the question
#                 question_match = re.search(r'\*\*Question [0-9]+:\*\*\s*(.+)', block)
#                 options_match = re.search(r'Options:\s*(.+)', block)
#                 answer_match = re.search(r'\*\*Correct Answer:\*\*\s*(.+)', block)

#                 if question_match and options_match and answer_match:
#                     question = question_match.group(1).strip()
#                     options_text = options_match.group(1).strip()
#                     answer_text = answer_match.group(1).strip()

#                     # Extract options
#                     options = [opt.strip() for opt in options_text.split(',')]
#                     correct_option_letter = answer_text[0]  # e.g., "A" from "A. Option 1"
#                     correct_option = None

#                     # Match correct answer with the corresponding option
#                     for i, opt in enumerate(options):
#                         if opt.startswith(correct_option_letter):
#                             correct_option = i + 1
#                             break

#                     if len(options) == 4 and correct_option:
#                         questions.append({
#                             "text": question,
#                             "option1": options[0][3:].strip(),  # Remove "A. " from the start
#                             "option2": options[1][3:].strip(),
#                             "option3": options[2][3:].strip(),
#                             "option4": options[3][3:].strip(),
#                             "correct_option": correct_option,
#                             "question_set": None  # Initially set to None
#                         })

#         return questions

#     def _get_next_question_set_name(self, user):
#         last_question_set = QuestionSet.objects.filter(user=user).order_by('-created_at').first()
#         if last_question_set:
#             last_part_num = int(last_question_set.name.split('part ')[-1])
#             return f'part {last_part_num + 1}'
#         return 'part 1'

class QuestionApiView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        user = request.user
        questions = Question.objects.filter(user=user)
        serializer = QuestionSerializer(questions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def post(self, request, *args, **kwargs):
        data = request.data
        serializer = QuestionSerializer(data=data, context={'request': request})
        
        if serializer.is_valid():
            try:
                question = serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class QuestionApiDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk=None):
        if pk:
            try:
                question = Question.objects.get(pk=pk, user=request.user)
                serializer = QuestionSerializer(question)
                return Response(serializer.data, status=status.HTTP_200_OK)
            except Question.DoesNotExist:
                raise NotFound("Question not found or not accessible by the user")
        else:
            questions = Question.objects.filter(user=request.user)
            serializer = QuestionSerializer(questions, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk=None):
        try:
            question = Question.objects.get(pk=pk, user=request.user)
        except Question.DoesNotExist:
            raise NotFound("Question not found or not accessible by the user")
        
        serializer = QuestionSerializer(question, data=request.data, partial=True, context={'request': request})
        
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk=None):
        try:
            question = Question.objects.get(pk=pk, user=request.user)
            question.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Question.DoesNotExist:
            raise NotFound("Question not found or not accessible by the user")
         

class OwnersView(APIView):
    def get(self, request):
        owners = CustomUser.objects.filter(is_player=False)
        serializer = UserWithQuestionCountSerializer(owners, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)



class OwnerAllQuestionView(APIView):
    def get(self,request,username=None):
        questions = Question.objects.filter(user__username=username)
        serializer = QuestionSerializer(questions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    

class ScoreView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """List all scores for the authenticated user."""
        scores = Score.objects.filter(user=request.user)
        serializer = ScoreSerializer(scores, many=True)
        return Response(serializer.data)

    def post(self, request):
        """Create or update a score for a question set."""
        user = request.user
        question_set_id = request.data.get('question_set')
        score_value = request.data.get('score')
        total_value = request.data.get('total')
        
        # Ensure that the question_set_id, score, and total are provided
        if not question_set_id or score_value is None or total_value is None:
            return Response({"error": "question_set, score, and total are required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            question_set = QuestionSet.objects.get(id=question_set_id, user=user)
        except QuestionSet.DoesNotExist:
            return Response({"error": "Question Set does not exist or does not belong to you."}, status=status.HTTP_400_BAD_REQUEST)

        # Use update_or_create to either update the existing score or create a new one
        score, created = Score.objects.update_or_create(
            question_set=question_set,
            user=user,
            defaults={'score': score_value, 'total': total_value}
        )

        # Serialize the score data for the response
        serializer = ScoreSerializer(score)
        status_code = status.HTTP_201_CREATED if created else status.HTTP_200_OK
        return Response(serializer.data, status=status_code)
    
     
class ScoreDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, question_set_id, user):
        try:
            return Score.objects.get(question_set__id=question_set_id, user=user)
        except Score.DoesNotExist:
            raise NotFound("Score not found.")

    def get(self, request, question_set_id):
        """Retrieve a specific score for a question set."""
        score = self.get_object(question_set_id, request.user)
        serializer = ScoreSerializer(score)
        return Response(serializer.data)

    def put(self, request, question_set_id):
        """Update a specific score for a question set."""
        score = self.get_object(question_set_id, request.user)
        serializer = ScoreSerializer(score, data=request.data, context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, question_set_id):
        """Delete a specific score for a question set."""
        score = self.get_object(question_set_id, request.user)
        score.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)