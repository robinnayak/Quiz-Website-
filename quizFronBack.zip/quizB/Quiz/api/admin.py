from django.contrib import admin
from .models import Question,CustomUser,QuestionSet,Score
# Register your models here.
admin.site.register(CustomUser)
admin.site.register(Question)
admin.site.register(QuestionSet )
admin.site.register(Score)

