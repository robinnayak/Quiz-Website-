import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import Navbar from "./components/Navbar"; // Import the Navbar component
import { store } from "./app/store";
import { Provider} from "react-redux";
import Login from "./AuthScreen/Login";
import Register from "./AuthScreen/Register";
import PrivateRoute from "./components/services/PrivateRoute";
import About from "./components/About";
import Score from "./components/Score";
import QuestionSetDetail from "./components/QuestionSetDetail";
import Settings from "./AuthScreen/Settings";

const App = () => {
  return (
    <BrowserRouter>
      <Provider store={store}>
        <Navbar /> {/* Navbar is outside of the routes */}
        <Routes>
          <Route path="/" element={<PrivateRoute><Home /></PrivateRoute>} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/settings" element={<PrivateRoute><Settings /></PrivateRoute>} />
          <Route path="/score" element={<PrivateRoute><Score /></PrivateRoute>} />
          <Route path="/scores/:questionSetId" element={<PrivateRoute><QuestionSetDetail /></PrivateRoute>} />

          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<div>Contact Page</div>} />
        </Routes>
      </Provider>
    </BrowserRouter>
  );
};

export default App;
