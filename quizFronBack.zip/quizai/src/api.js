import { GoogleGenerativeAI } from "@google/generative-ai";

// Directly assigning the API key
const GEMINI_API_KEY = "AIzaSyBO1epKeznsNoiVi_F1yO08Ohu1aHRx9Lw";

// Initialize the Google Generative AI with the API key
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
console.log("Google Generative AI initialized:", genAI);

export const fetchQuizQuestions = async (category) => {
  console.log("Fetching questions for category:", category);
  try {
    const prompt = `Generate a list of quiz questions for the category "${category}" with four multiple-choice answers each. Format the output as 'Question: [question text] Options: [Option A, Option B, Option C, Option D]' Correct Answer: Option A`;

    console.log("Prompt for question generation:", prompt);

    const model = await genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    console.log("Generative model obtained:", model);

    const result = await model.generateContent([prompt]);
    console.log("Result from generateContent:", result);

    const rawText = result.response.text();
    console.log("Raw generated data:", rawText);

    const questions = parseQuestions(rawText);
    console.log("Parsed questions:", questions);

    return questions;
  } catch (error) {
    console.error("Error fetching questions:", error);
    return [];
  }
};

function parseQuestions(rawText) {
  // Split the raw text into blocks for each question
  const questionBlocks = rawText.split("\n\n");
  const questions = [];

  console.log("Raw text received:");
  console.log(rawText);
  console.log("=====================================================");

  questionBlocks.forEach((block, index) => {
    console.log(`Processing block ${index + 1}:`);
    console.log(block);
    console.log("-----------------------------------------------------");

    if (block.trim()) {
      // Match the question text
      const questionMatch = block.match(/\*\*\d+\. Question:\*\* (.+)/);
      console.log("Question match:", questionMatch);

      // Match the options text
      const optionsMatch = block.match(/\*\*Options:\*\* ([\s\S]+?)\*\*Correct Answer/);
      console.log("Options match:", optionsMatch);

      // Match the correct answer
      const answerMatch = block.match(/\*\*Correct Answer:\*\* (.+)/);
      console.log("Answer match:", answerMatch);

      if (questionMatch && optionsMatch && answerMatch) {
        const question = questionMatch[1].trim();
        let optionsText = optionsMatch[1].trim();
        let answer = answerMatch[1].trim();

        console.log("Parsed question:", question); 
        console.log("Parsed options text:", optionsText);
        console.log("Parsed answer:", answer);

        // Clean up options and remove unwanted characters like [, ], and leading "A) ", "B) ", etc.
        optionsText = optionsText.replace(/[\[\]]/g, ""); // Remove square brackets
        const options = optionsText.split(", ").map(opt => opt.replace(/^[A-D]\)\s*/, "").trim()); // Remove "A) ", "B) ", etc.

        // Clean up the answer by removing the leading "A) ", "B) ", etc.
        answer = answer.replace(/^[A-D]\)\s*/, "").trim();
        console.log("Cleaned Options array:", options);
        console.log("Cleaned Answer:", answer);

        // Add to questions array only if there are 4 options
        if (options.length === 4) {
          console.log("Adding question to array");
          questions.push({
            question,
            options,
            answer
          });
          console.log("Added question object:", {
            question,
            options,
            answer
          });
        } else {
          console.log("Skipping block due to incorrect number of options.");
        }
      } else {
        console.log("Skipping block due to missing matches.");
      }
      console.log("=====================================================");
    }
  });

  console.log("Final parsed questions array:", questions);
  console.log("=====================================================");
  return questions;
}
