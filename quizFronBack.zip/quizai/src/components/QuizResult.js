import React, { useEffect } from "react";
import axios from "axios";
import { BASE_URL } from "./services/baseurl";
import { useSelector } from "react-redux";


const QuizResult = ({ score, total, onResetQuiz, questionSetId }) => {
  const percentage = (score / total) * 100;
  const token = useSelector(state=>state.auth.token)
  useEffect(() => {
    // Function to send the score to the backend
    const submitScore = async () => {
      try {
        const response = await axios.post(
          `${BASE_URL}/scores/`,
          {
            question_set: questionSetId,
            score: score,
            total: total,
          },
          {
            headers: {
              "Content-Type": "application/json",
              // Add Authorization header if token is available
              Authorization: `Bearer ${token}`,
            },
          }
        );
        console.log("Score submitted successfully:", response.data);
      } catch (error) {
        console.error("Error submitting score:", error.response?.data || error.message);
      }
    };

    // Call the submitScore function when the component mounts
    submitScore();
  }, [score, total, questionSetId,token]);

  return (
    <div className="text-center p-6 rounded-lg bg-gray-100 shadow-lg max-w-lg mx-auto mt-12">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Your Score</h2>
      <p className="text-lg text-gray-600">
        You answered <strong>{score}</strong> out of <strong>{total}</strong> questions correctly.
      </p>
      {percentage > 60 && (
        <div className="mt-5 p-4 rounded-lg bg-green-100 text-green-800 text-xl font-semibold animate-fadeIn">
          🎉 Congratulations! 🎉
          <p className="mt-2 text-lg font-bold">You scored more than 60%!</p>
        </div>
      )}
      <button
        onClick={onResetQuiz}
        className="mt-8 px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
      >
        Retake Quiz
      </button>
    </div>
  );
};

export default QuizResult;
