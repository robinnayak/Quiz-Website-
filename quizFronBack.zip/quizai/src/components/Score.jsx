import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { BASE_URL } from './services/baseurl';
import { useSelector } from 'react-redux';


const Score = () => {
  const [scores, setScores] = useState([]);
  const navigate = useNavigate();
    const token = useSelector(state=>state.auth.token)
  useEffect(() => {
    // Fetch scores from the API
    const fetchScores = async () => {
      try {
        const response = await axios.get(`${BASE_URL}/scores/`,{
            headers:{
                "Authorization":`Bearer ${token}`
            }
        });
        setScores(response.data);
      } catch (error) {
        console.error('Error fetching scores:', error);
      }
    };

    fetchScores();
  }, [token]);

  // Handle click on a specific question set
  const handleCardClick = (questionSetId) => {
    navigate(`/scores/${questionSetId}`);
  };

  return (
    <div className="container mx-auto mt-10">
      <h1 className="text-3xl font-bold text-center mb-8">Your Quiz Scores</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {scores.map((score) => (
          <div
            key={score.id}
            className="bg-white shadow-lg rounded-lg p-4 hover:shadow-xl cursor-pointer"
            onClick={() => handleCardClick(score.question_set.id)}
          >
            <h2 className="text-xl font-semibold mb-2">{score.question_set.name}</h2>
            <p className="text-gray-600 mb-2">Created at: {new Date(score.created_at).toLocaleDateString()}</p>
            <p className="text-gray-600">Score: {score.score} / {score.total}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Score;
