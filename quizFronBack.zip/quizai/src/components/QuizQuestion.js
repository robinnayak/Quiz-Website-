import React, { useEffect, useState } from "react";

const QuizQuestion = ({
  question,
  options,
  onSelectAnswer,
  currentQuestionIndex,
  totalQuestions,
  onTimeUp = () => {},  // Default function to avoid errors if onTimeUp is not passed
}) => {
  const [timeLeft, setTimeLeft] = useState(60); // 1-minute timer

  useEffect(() => {
    if (timeLeft === 0) {
      onTimeUp(); // Automatically move to the next question
    }

    const timer = setInterval(() => {
      setTimeLeft((prevTime) => (prevTime > 0 ? prevTime - 1 : 0));
    }, 1000);

    return () => clearInterval(timer); // Cleanup timer on component unmount
  }, [timeLeft, onTimeUp]);

  useEffect(() => {
    setTimeLeft(60); // Reset timer when question changes
  }, [currentQuestionIndex]);

  return (
    <div className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 p-8 rounded-lg shadow-lg text-white animate-fadeInCustom">
      <h2 className="text-2xl font-bold mb-4">
        Question {currentQuestionIndex} of {totalQuestions}
      </h2>
      <p className="text-lg mb-6">{question}</p>
      <div className="space-y-4">
        {options.map((option, index) => (
          <button
            key={index}
            onClick={() => onSelectAnswer(option)}
            className="w-full bg-white text-gray-800 py-2 px-4 rounded-lg shadow-md hover:bg-gray-200 transition duration-300 ease-in-out"
          >
            {option}
          </button>
        ))}
      </div>
      <div className="mt-6 text-right text-lg">
        Time Left: <span className="font-bold">{timeLeft}s</span>
      </div>
    </div>
  );
};

export default QuizQuestion;
