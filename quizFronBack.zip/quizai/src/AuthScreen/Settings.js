import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';
import { BASE_URL } from '../components/services/baseurl';
import { useNavigate } from 'react-router-dom';

const Settings = () => {
  const [user, setUser] = useState(null);
  const token = useSelector(state => state.auth.token);
  const navigate = useNavigate();
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`${BASE_URL}/register-detail/`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        setUser(response.data.data);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, [token]);

  const handleDelete = async () => {
    try {
      await axios.delete(`${BASE_URL}/register-detail/`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      alert('Profile deleted successfully');
      navigate("/login");
      
      // Optionally, redirect or handle post-deletion logic
    } catch (error) {
      console.error('Error deleting profile:', error);
      alert('Error deleting profile');
    }
  };

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">Settings</h1>
      {user ? (
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <h2 className="text-2xl font-semibold mb-4">User Information</h2>
          <p className="text-lg mb-2"><strong>Username:</strong> {user.username}</p>
          <p className="text-lg mb-2"><strong>Email:</strong> {user.email}</p>
          <p className="text-lg mb-4"><strong>Player Status:</strong> {user.is_player ? 'Player' : 'Not a Player'}</p>
          <button
            onClick={handleDelete}
            className="bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600 transition-colors"
          >
            Delete Profile
          </button>
        </div>
      ) : (
        <p className="text-lg">Loading...</p>
      )}
    </div>
  );
};

export default Settings;
