import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  user_id: "",
  username: "",
  email: "",
  token: "",
  is_player: ""
};

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setAuth: (state, action) => {
      console.log("action", action.payload);
      state.user_id = action.payload.userData.id || ""; // user_id
      state.username = action.payload.userData.username || "";
      state.email = action.payload.userData.email || "";
      state.token = action.payload.token || "";
      state.is_player = action.payload.userData.is_player || "";
    },
    logout: (state) => {
      // Reset the state to initial values on logout
      state.user_id = "";
      state.username = "";
      state.email = "";
      state.token = "";
      state.is_player = "";
    },
  },
});

export const { setAuth, logout } = authSlice.actions;
export default authSlice.reducer;
