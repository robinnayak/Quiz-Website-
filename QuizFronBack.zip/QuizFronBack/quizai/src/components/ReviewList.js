import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BASE_URL } from './services/baseurl';
import { useSelector } from 'react-redux';

const ReviewList = ({ questionSetId }) => {
  const [reviews, setReviews] = useState([]);
  const token = useSelector(state => state.auth.token);

  useEffect(() => {
    // Fetch reviews for the specific question set
    const fetchReviews = async () => {
      try {
        const response = await axios.get(
          `${BASE_URL}/question-sets/${questionSetId}/reviews/`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setReviews(response.data);
      } catch (error) {
        console.error('Error fetching reviews:', error);
      }
    };

    fetchReviews();
  }, [questionSetId, token]);

  const renderStars = (rating) => {
    return [...Array(5)].map((_, index) => (
      <span key={index} className={index < rating ? 'text-yellow-500' : 'text-gray-300'}>
        ★
      </span>
    ));
  };

  return (
    <div className="mt-4">
      <h3 className="text-lg font-semibold">Reviews:</h3>
      {reviews.length > 0 ? (
        reviews.map((review) => (
          <div key={review.id} className="bg-white shadow p-4 mt-2 rounded-lg">
            <div className="flex items-center mb-2">
              <div className="flex">{renderStars(review.rating)}</div>
              <span className="ml-2 text-sm text-gray-600">{review.rating}/5</span>
            </div>
            <p className="text-sm text-gray-800 mb-1">{review.comment}</p>
            <p className="text-xs text-gray-400">
              <em>Posted on: {new Date(review.created_at).toLocaleDateString()}</em>
            </p>
          </div>
        ))
      ) : (
        <p className="text-sm text-gray-500">No reviews yet.</p>
      )}
    </div>
  );
};

export default ReviewList;
