// src/components/Home.js
import React, { useState, useEffect } from "react";
import axios from "axios";
import QuizResult from "./QuizResult";
import QuizCategorySelector from "./QuizCategorySelector";
import QuizQuestion from "./QuizQuestion";
import { useSelector } from "react-redux";
import { BASE_URL } from "./services/baseurl";

const Home = () => {
  const token = useSelector((state) => state.auth.token);
  const username = useSelector((state) => state.auth.username);
  const [categories] = useState([
    "Science",
    "History",
    "Math",
    "Geography",
    "Social Engineering",
  ]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [numQuestions, setNumQuestions] = useState(5);
  const [questions, setQuestions] = useState([]);
  const [questionSetId, setQuestionSetId] = useState(null); // Store the Question Set ID
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState([]);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  useEffect(() => {
    if (selectedCategory && numQuestions > 0) {
      const loadQuestions = async () => {
        try {
          const response = await axios.post(
            `${BASE_URL}/generate-questions/`,
            {
              category: selectedCategory,
              num_questions: numQuestions,
            },
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`, // Include token if necessary
            }
          });

          const questionsData = response.data.questions.map((question) => ({
            text: question.text,
            options: [
              question.option1,
              question.option2,
              question.option3,
              question.option4,
            ],
            correctOption: question.correct_option,
          }));

          setQuestions(questionsData);
          console.log("questionset id ", response.data.id)
          setQuestionSetId(response.data.id); // Store the Question Set ID
        } catch (error) {
          console.error("Error fetching questions:", error);
        }
      };

      loadQuestions();
    }
  }, [selectedCategory, numQuestions, token]);

  const handleSelectAnswer = (answer) => {
    const correctAnswer =
      questions[currentQuestionIndex].options[
        questions[currentQuestionIndex].correctOption - 1
      ];
    setUserAnswers([...userAnswers, answer]);

    if (answer === correctAnswer) {
      setScore(score + 1);
    }

    if (currentQuestionIndex + 1 < questions.length) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setQuizFinished(true);
    }
  };

  const handleResetQuiz = () => {
    setSelectedCategory("");
    setNumQuestions(5);
    setQuestions([]);
    setCurrentQuestionIndex(0);
    setUserAnswers([]);
    setScore(0);
    setQuizFinished(false);
  };

  return (
    <div className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 min-h-screen flex flex-col items-center justify-center">
      <h1 className="text-4xl font-bold text-white text-center mt-8 mb-8 animate-fadeInCustom">
        Welcome, {username}! Ready for the Quiz?
      </h1>
      {!selectedCategory && (
        <QuizCategorySelector
          categories={categories}
          onSelectCategory={setSelectedCategory}
          onSelectNumQuestions={setNumQuestions}
        />
      )}
      {selectedCategory && !quizFinished && questions.length > 0 && (
        <QuizQuestion
          question={questions[currentQuestionIndex].text}
          options={questions[currentQuestionIndex].options}
          onSelectAnswer={handleSelectAnswer}
          currentQuestionIndex={currentQuestionIndex + 1}
          totalQuestions={questions.length}
        />
      )}
      {quizFinished && (
        <QuizResult
          score={score}
          total={questions.length}
          onResetQuiz={handleResetQuiz}
          questionSetId={questionSetId} // Pass the Question Set ID to QuizResult
        />
      )}
    </div>
  );
};

export default Home;
