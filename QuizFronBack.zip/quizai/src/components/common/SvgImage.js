import React from 'react';
import { createAvatar } from "@dicebear/core";
import { avataaars } from "@dicebear/collection";

const SvgImage = ({ seed, width = 50, height = 50 }) => {
  const avatarSvg = createAvatar(avataaars, {
    seed: seed,
    width: width,
    height: height,
  }).toString();

  return (
    <div
      className={`rounded-full cursor-pointer transform transition-transform duration-300 hover:scale-110`}
      style={{ width: `${width}px`, height: `${height}px` }}
      dangerouslySetInnerHTML={{ __html: avatarSvg }}
    />
  );
};

export default SvgImage;
