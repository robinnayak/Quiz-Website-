import React from 'react';

const About = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-center mb-6">About QuizAI</h1>
      <p className="text-lg leading-relaxed mb-4">
        Welcome to <span className="font-semibold">QuizAI</span>! Our platform offers an engaging and interactive way to test your knowledge across various subjects. Powered by the advanced capabilities of <span className="font-semibold">Gemini AI</span>, each quiz is uniquely generated to challenge and entertain you.
      </p>
      <p className="text-lg leading-relaxed">
        Whether you're looking to brush up on your trivia skills or dive deep into specific topics, QuizAI has something for everyone. Join us and embark on a journey of endless learning and fun!
      </p>
    </div>
  );
};

export default About;
