import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { BASE_URL } from "./services/baseurl";
import { useSelector } from 'react-redux';

const QuestionSetDetail = () => {
  const { questionSetId } = useParams();
  const [questionSet, setQuestionSet] = useState(null);
  const token = useSelector(state => state.auth.token);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch specific question set details by ID
    const fetchQuestionSet = async () => {
      try {
        const response = await axios.get(
          `${BASE_URL}/scores/${questionSetId}/`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setQuestionSet(response.data.question_set); // Extract question_set from response
      } catch (error) {
        console.error("Error fetching question set:", error);
        navigate("/scores"); // Redirect back to scores if an error occurs
      }
    };

    fetchQuestionSet();
  }, [questionSetId, token, navigate]);

  if (!questionSet) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto mt-10">
      <h1 className="text-3xl font-bold text-center mb-8">
        {questionSet.name}
      </h1>
      <div className="bg-white shadow-lg rounded-lg p-4">
        {questionSet.questions && questionSet.questions.length > 0 ? (
          questionSet.questions.map((question) => (
            <div key={question.id} className="mb-4">
              <h2 className="text-lg font-semibold mb-2">{question.text}</h2>
              <ul className="list-disc ml-5">
                <li>{question.option1}</li>
                <li>{question.option2}</li>
                <li>{question.option3}</li>
                <li>{question.option4}</li>
              </ul>
              <p className="text-green-600 mt-2">
                Correct Option: {question[`option${question.correct_option}`]}
              </p>
            </div>
          ))
        ) : (
          <p>No questions found for this set.</p>
        )}
      </div>
    </div>
  );
};

export default QuestionSetDetail;
