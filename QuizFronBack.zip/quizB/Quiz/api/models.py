from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, Group, Permission, PermissionsMixin   
from django.conf import settings

class CustomUserManger (BaseUserManager):
    def create_user(self, username, email, password,is_player, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(username=username, email=email,is_player=is_player,**extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        
        return user
    
    def create_superuser(self,username,email,password,**extra_fields):
        extra_fields.setdefault('is_staff',True)
        extra_fields.setdefault('is_superuser',True)
        extra_fields.setdefault('is_active',True)
        print("extra kwargs",extra_fields)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('superuser must have is_staff=True')
        
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have a superuser=True')
        
        user = self.model(
            username=username,
            email = email,
            **extra_fields
        )
        user.set_password(password)
        user.save(using=self._db)
        return user
    
class CustomUser(AbstractBaseUser, PermissionsMixin):
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=128)
    is_player = models.BooleanField(default=False)
    date_joined = models.DateTimeField(auto_now_add=True)

    groups = models.ManyToManyField(Group,
                                    verbose_name='groups',
                                    blank=True,
                                    related_name='group_related_user',
                                    related_query_name='group_user')
    
    user_permissions = models.ManyToManyField(Permission,verbose_name=  'user permissions', blank=True, help_text="Specific permissions for the user", related_name='permission_user', related_query_name='permission_related_user') 
    
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    objects = CustomUserManger()
    
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email','password']
    

    def __str__(self) -> str:
        return self.username


class QuestionSet(models.Model):
    name = models.CharField(max_length=50, help_text="Name of the question set, e.g., 'part 1', 'part 2'")
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Question(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    question_set = models.ForeignKey(QuestionSet, on_delete=models.CASCADE, related_name='questions')
    text = models.CharField(max_length=255, help_text="Enter the question text")
    option1 = models.CharField(max_length=100, help_text="Enter option 1")
    option2 = models.CharField(max_length=100, help_text="Enter option 2")
    option3 = models.CharField(max_length=100, help_text="Enter option 3")
    option4 = models.CharField(max_length=100, help_text="Enter option 4")
    correct_option = models.IntegerField(choices=[(1, 'Option 1'), (2, 'Option 2'), (3, 'Option 3'), (4, 'Option 4')], help_text="Select the correct option")

    def __str__(self):
        return self.text
    
    
class Score(models.Model):
    question_set = models.OneToOneField(QuestionSet, on_delete=models.CASCADE, related_name='score')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    score = models.IntegerField(help_text="Score achieved for this question set")
    total = models.IntegerField(help_text="Total questions in the set")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username} - {self.question_set.name}: {self.score}/{self.total}'
    
    
class Review(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    question_set = models.ForeignKey(QuestionSet, on_delete=models.CASCADE, related_name='reviews')
    rating = models.IntegerField(choices=[(1, '1 Star'), (2, '2 Stars'), (3, '3 Stars'), (4, '4 Stars'), (5, '5 Stars')], help_text="Rating out of 5")
    comment = models.TextField(blank=True, null=True, help_text="Optional comment for the review")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username} - {self.question_set.name} Review'