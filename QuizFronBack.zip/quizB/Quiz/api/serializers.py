from  rest_framework import serializers
from .models  import CustomUser, Question, QuestionSet,Score,Review
from django.contrib.auth.hashers import check_password
from rest_framework.exceptions import NotFound
from rest_framework.exceptions import ValidationError

class CustomUserSerializer(serializers.ModelSerializer):
    password2 = serializers.CharField(style={'input_type': 'password'}, write_only=True)    
    class Meta:
        model = CustomUser
        fields = ['id','username','password','password2','email','is_player']   
        extra_kwargs = {
            'password': {'write_only': True}
        }
        
    def validate(self, data):
        
        if 'username' in data:
            if CustomUser.objects.filter(username=data['username']).exists():
                raise serializers.ValidationError("Username already exists")  

        password = data.get('password')
        password2 = data.get('password2')
        
        if password != password2:
            raise serializers.ValidationError("Passwords must match") 
        print("validated data: ",data)
        return data
    
    def create(self, validated_data):
        print("create valiodated data: ",validated_data)
        
        validated_data.pop('password2') 
        user = CustomUser.objects.create_user(**validated_data)  
        return user
    
    def to_representation(self, instance):
        print("instance data: ",instance)
        
        request = self.context.get('request')   
        method  = request.method if request else None
        if method == 'GET':
            self.fields.pop('password2',None) 
        
        return super().to_representation(instance)         
    

class CustomUserLoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()
    
    def validate(self, data):  
        if 'password' in data and 'username' in data:
            user = CustomUser.objects.get(username=data['username'])
            if not user:
                raise serializers.ValidationError("User not found") 
            if not user.check_password(data['password']):
                raise serializers.ValidationError("Invalid password")
        return data 
    
class UserWithQuestionCountSerializer(serializers.ModelSerializer):
    question_count = serializers.SerializerMethodField()

    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'question_count']

    def get_question_count(self, obj):
        return Question.objects.filter(user=obj).count()

class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ['id', 'user', 'question_set', 'text', 'option1', 'option2', 'option3', 'option4', 'correct_option']
        read_only_fields = ['user', 'question_set']  # User and question_set are read-only

    def create(self, validated_data):
        user = self.context.get('request').user  # Get the user from request context
        question_set = self.context.get('question_set')  # Get the question set from context
        
        if not user:
            raise serializers.ValidationError("User not authenticated")
        
        if not question_set:
            raise serializers.ValidationError("Question set not provided")

        # Create the Question instance with the provided validated data
        question = Question.objects.create(user=user, question_set=question_set, **validated_data)
        return question


class QuestionSetSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True, read_only=True)  # Nested Question serializer

    class Meta:
        model = QuestionSet
        fields = ['id', 'name', 'user', 'created_at', 'questions']  # Include related questions
        read_only_fields = ['user', 'created_at']

    def create(self, validated_data):
        user = self.context.get('request').user  # Get the user from request context
        if not user:
            raise serializers.ValidationError("User not authenticated")

        # Create the QuestionSet instance with the provided validated data
        question_set = QuestionSet.objects.create(user=user, **validated_data)
        return question_set


class ScoreSerializer(serializers.ModelSerializer):
    question_set = QuestionSetSerializer()
    class Meta:
        model = Score
        fields = ['id', 'question_set', 'user', 'score', 'total', 'created_at']
        read_only_fields = ['user', 'created_at']

    def validate(self, data):
        # Ensure that the score is not created if it already exists for the QuestionSet
        user = self.context.get('request').user
        question_set = data.get('question_set')

        if Score.objects.filter(user=user, question_set=question_set).exists():
            raise ValidationError("Score for this Question Set already exists.")
        
        return data

    def create(self, validated_data):
        user = self.context.get('request').user
        validated_data['user'] = user
        return super().create(validated_data)
    


class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ['id', 'user', 'question_set', 'rating', 'comment', 'created_at']
        read_only_fields = ['user', 'created_at']

    def create(self, validated_data):
        user = self.context['request'].user
        review = Review.objects.create(user=user, **validated_data)
        return review


